﻿using System;
using System.Windows;

namespace MarketplaceWpf
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnLoadUsers_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                dgUsers.ItemsSource = UserRepository.GetAll();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }

        private void btnAddUser_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var user = new User
                {
                    Login = txtLogin.Text,
                    Password = txtPassword.Text,
                    Name = txtName.Text,
                    Surname = txtSurname.Text,
                    Patronymic = string.IsNullOrWhiteSpace(txtPatronymic.Text) ? null : txtPatronymic.Text,
                    Email = txtEmail.Text,
                    PhoneNumber = txtPhone.Text,
                    Role = string.IsNullOrWhiteSpace(txtRole.Text) ? "User" : txtRole.Text
                };
                UserRepository.Add(user);
                MessageBox.Show("Пользователь добавлен");
                // очистить поля
                txtLogin.Clear(); txtPassword.Clear(); txtName.Clear(); txtSurname.Clear();
                txtPatronymic.Clear(); txtEmail.Clear(); txtPhone.Clear(); txtRole.Clear();
                // обновить список
                btnLoadUsers_Click(sender, e);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }
    }
}