﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using Microsoft.Data.SqlClient;

public static class OrderRepository
{
    // Получить заказы пользователя за период через процедуру UserOrders
    public static List<Order> GetUserOrders(int customerId, DateTime from, DateTime to)
    {
        var orders = new List<Order>();
        using var conn = new SqlConnection(DatabaseHelper.GetConnectionString());
        conn.Open();
        using var cmd = new SqlCommand("UserOrders", conn) { CommandType = System.Data.CommandType.StoredProcedure };
        cmd.Parameters.AddWithValue("@CustomerID", customerId);
        cmd.Parameters.AddWithValue("@Datefrom", from);
        cmd.Parameters.AddWithValue("@DateTo", to);
        using var reader = cmd.ExecuteReader();
        while (reader.Read())
        {
            orders.Add(new Order
            {
                ID = (int)reader["ID"],
                EntryDate = (DateTime)reader["Entrydate"],
                Price = Convert.ToDouble(reader["Price"]),
                Status = reader["Status"].ToString(),
                AddressPath = reader["Addresspath"].ToString(),
                // ProductName не входит в Order, но можно игнорировать или добавить отдельное свойство
            });
        }
        return orders;
    }

    // Обновить статус заказа с транзакцией (для демонстрации)
    public static void UpdateStatus(int orderId, string newStatus)
    {
        using var conn = new SqlConnection(DatabaseHelper.GetConnectionString());
        conn.Open();
        using var tran = conn.BeginTransaction();
        try
        {
            string sql = "UPDATE [Order] SET Status = @status WHERE ID = @id";
            using var cmd = new SqlCommand(sql, conn, tran);
            cmd.Parameters.AddWithValue("@status", newStatus);
            cmd.Parameters.AddWithValue("@id", orderId);
            if (cmd.ExecuteNonQuery() == 0)
                throw new Exception("Заказ не найден");
            tran.Commit();
        }
        catch
        {
            tran.Rollback();
            throw;
        }
    }
}