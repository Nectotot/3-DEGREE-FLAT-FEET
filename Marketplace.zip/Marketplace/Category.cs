﻿public class Category
{
    public int ID { get; set; }
    public string NameTag { get; set; }
    public int? Subcategory { get; set; } // внешний ключ на родительскую категорию
}