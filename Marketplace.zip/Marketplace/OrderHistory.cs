﻿using System;

public class OrderHistory
{
    public int ID { get; set; }
    public int OrderID { get; set; }
    public string PrevStatus { get; set; }
    public string NextStatus { get; set; }
    public DateTime ModdedDate { get; set; }
    public string Commentary { get; set; }
}