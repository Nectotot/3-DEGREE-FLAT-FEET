﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using Microsoft.Data.SqlClient;

public static class ProductRepository
{
    // Получить все активные товары
    public static List<Product> GetActiveProducts()
    {
        var products = new List<Product>();
        using var conn = new SqlConnection(DatabaseHelper.GetConnectionString());
        conn.Open();
        string sql = @"SELECT ID, ShopassistID, CategoryID, ProductName, Description, Price, Amount, Entrydate, is_active 
                       FROM Product WHERE is_active = 1";
        using var cmd = new SqlCommand(sql, conn);
        using var reader = cmd.ExecuteReader();
        while (reader.Read())
        {
            products.Add(new Product
            {
                ID = (int)reader["ID"],
                ShopAssistID = (int)reader["ShopassistID"],
                CategoryID = reader["CategoryID"] as int?,
                ProductName = reader["ProductName"].ToString(),
                Description = reader["Description"].ToString(),
                Price = Convert.ToDouble(reader["Price"]),
                Amount = (int)reader["Amount"],
                EntryDate = (DateTime)reader["Entrydate"],
                IsActive = (bool)reader["is_active"]
            });
        }
        return products;
    }

    // Поиск товаров через процедуру SearchProducts
    public static List<Product> Search(string name, double? minPrice, double? maxPrice)
    {
        var products = new List<Product>();
        using var conn = new SqlConnection(DatabaseHelper.GetConnectionString());
        conn.Open();
        using var cmd = new SqlCommand("SearchProducts", conn) { CommandType = System.Data.CommandType.StoredProcedure };
        cmd.Parameters.AddWithValue("@Name", (object)name ?? DBNull.Value);
        cmd.Parameters.AddWithValue("@MinPrice", (object)minPrice ?? DBNull.Value);
        cmd.Parameters.AddWithValue("@MaxPrice", (object)maxPrice ?? DBNull.Value);
        using var reader = cmd.ExecuteReader();
        while (reader.Read())
        {
            products.Add(new Product
            {
                ID = (int)reader["ID"],
                ProductName = reader["ProductName"].ToString(),
                Description = reader["Description"]?.ToString(),
                Price = Convert.ToDouble(reader["Price"]),
                Amount = (int)reader["Amount"],
                // CategoryName получаем из reader["Category"], но в Product нет поля CategoryName, можно добавить или игнорировать.
                // Для простоты не будем заполнять CategoryID
            });
        }
        return products;
    }

    // Топ-10 товаров (возвращает анонимные объекты или специальный класс, но для простоты вернем список Product с доп полем SalesCount)
    // Лучше создать класс ProductSales, но ограничимся списком строк.
    public static List<string> GetTopProducts()
    {
        var list = new List<string>();
        using var conn = new SqlConnection(DatabaseHelper.GetConnectionString());
        conn.Open();
        using var cmd = new SqlCommand("TopProducts", conn) { CommandType = System.Data.CommandType.StoredProcedure };
        using var reader = cmd.ExecuteReader();
        while (reader.Read())
        {
            string line = $"{reader["ID"]}\t{reader["ProductName"]}\t{reader["Price"]}\t{reader["Category"]}\t{reader["SalesCount"]}";
            list.Add(line);
        }
        return list;
    }

    // Добавить товар через процедуру AddProduct
    public static void Add(Product product)
    {
        using var conn = new SqlConnection(DatabaseHelper.GetConnectionString());
        conn.Open();
        using var cmd = new SqlCommand("AddProduct", conn) { CommandType = System.Data.CommandType.StoredProcedure };
        cmd.Parameters.AddWithValue("@ShopassistID", product.ShopAssistID);
        cmd.Parameters.AddWithValue("@CategoryID", (object)product.CategoryID ?? DBNull.Value);
        cmd.Parameters.AddWithValue("@ProductName", product.ProductName);
        cmd.Parameters.AddWithValue("@Description", product.Description);
        cmd.Parameters.AddWithValue("@Price", product.Price);
        cmd.Parameters.AddWithValue("@Amount", product.Amount);
        cmd.ExecuteNonQuery();
    }
}