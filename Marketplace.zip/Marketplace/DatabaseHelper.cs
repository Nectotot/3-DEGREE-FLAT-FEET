﻿using System.Configuration;

public static class DatabaseHelper
{
    public static object ConfigurationManager { get; private set; }

    public static string GetConnectionString()
    {
        return ConfigurationManager.ConnectionString["MarketplaceDb"].ConnectionString;
    }
}