﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using Microsoft.Data.SqlClient;

public static class UserRepository
{
    // Получить всех пользователей (активных)
    public static List<User> GetAll()
    {
        var users = new List<User>();
        using var conn = new SqlConnection(DatabaseHelper.GetConnectionString());
        conn.Open();
        string sql = "SELECT ID, Login, Password, Name, Surname, Patronymic, Email, Phonenumber, Role, Regdate, is_active FROM [User]";
        using var cmd = new SqlCommand(sql, conn);
        using var reader = cmd.ExecuteReader();
        while (reader.Read())
        {
            users.Add(new User
            {
                ID = (int)reader["ID"],
                Login = reader["Login"].ToString(),
                Password = reader["Password"].ToString(),
                Name = reader["Name"].ToString(),
                Surname = reader["Surname"].ToString(),
                Patronymic = reader["Patronymic"] as string, // может быть DBNull
                Email = reader["Email"].ToString(),
                PhoneNumber = reader["Phonenumber"].ToString(),
                Role = reader["Role"].ToString(),
                RegDate = (DateTime)reader["Regdate"],
                IsActive = (bool)reader["is_active"]
            });
        }
        return users;
    }

    // Добавить пользователя через процедуру AddUser
    public static void Add(User user)
    {
        using var conn = new SqlConnection(DatabaseHelper.GetConnectionString());
        conn.Open();
        using var cmd = new SqlCommand("AddUser", conn) { CommandType = System.Data.CommandType.StoredProcedure };
        cmd.Parameters.AddWithValue("@Login", user.Login);
        cmd.Parameters.AddWithValue("@Password", user.Password);
        cmd.Parameters.AddWithValue("@Name", user.Name);
        cmd.Parameters.AddWithValue("@Surname", user.Surname);
        cmd.Parameters.AddWithValue("@Patronymic", (object)user.Patronymic ?? DBNull.Value);
        cmd.Parameters.AddWithValue("@Email", user.Email);
        cmd.Parameters.AddWithValue("@Phone", user.PhoneNumber);
        cmd.Parameters.AddWithValue("@Role", user.Role ?? "User");
        cmd.ExecuteNonQuery();
    }
}