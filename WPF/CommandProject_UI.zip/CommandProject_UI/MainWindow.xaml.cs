﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CommandProject_UI
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            LoginControl login = new();
            MainWindowContentControl.Content = login;
            login.ButtonClicked += ButtonClicked;
        }

        private void ButtonClicked(Object? sender, EventArgs e)
        {
            MainWindowContentControl.Content = new Label() { Content = ":)" };
        }
    }
}